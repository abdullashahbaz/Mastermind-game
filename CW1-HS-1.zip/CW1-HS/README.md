# F28HS Coursework 1
H00457206 - Task HS16 NOISE CODE

This program processes HS16 format images by applying a noise effect. The noise intensity can be adjusted through command-line arguments. Additionally, the program supports batch processing, allowing multiple images to be processed in a single command. After processing, images can be converted to the PPM format using the hsconvert utility.


How It Works
The program reads an input image file in HS16 format, applies noise based on the specified intensity, and saves the processed image to a new file. The noise intensity can range from 0 to 100. The program can handle multiple image processing tasks in one execution by taking multiple sets of arguments. Processed images can then be converted to the PPM format for compatibility with a wider range of image viewing and editing tools.


Compilation
Compile the program with the following command:
gcc -o process process.c
This creates an executable named process from process.c.


Usage
Processing Images
To process an image, use:
./process INPUTFILE OUTPUTFILE NOISE_INTENSITY
INPUTFILE: Path to the HS16 image.
OUTPUTFILE: Path for the processed image.
NOISE_INTENSITY: Integer from 0 to 100 for noise level.


Single Image Processing
Example:
./process coffee.hs16 coffee-processed.hs16 15

Batch Processing
To process multiple images:
./process coffee.hs16 coffee-processed.hs16 15 wildcat.hs16 wildcat-processed.hs16 20 music.hs16 music-processed.hs16 12 white.hs16 white-processed.hs16 17

Converting Processed Images to PPM
After processing, convert the HS16 images to PPM format for broader compatibility:
./hsconvert -f PPM coffee-processed.hs16 coffee.ppm
This command uses the hsconvert utility to convert coffee-processed.hs16 to a PPM image named coffee.ppm. Ensure hsconvert is correctly installed and accessible in your system's PATH. After converting you will be able to see noisy image


Redirecting Output
To save code output:
./process coffee.hs16 coffee-processed.hs16 15 > code.log


