/* This coursework specification, and the example code provided during the
 * course, is Copyright 2024 Heriot-Watt University.
 * Distributing this coursework specification or your solution to it outside
 * the university is academic misconduct and a violation of copyright law. */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

/* The RGB values of a pixel, adjusted for HS16 format. */
struct Pixel {
    uint16_t red;   // Using uint16_t for 16-bit unsigned integers
    uint16_t green;
    uint16_t blue;
};

/* An image loaded from a file, including dimensions and pixel data. */
struct Image {
    int width;              // The width of the image in pixels
    int height;             // The height of the image in pixels
    struct Pixel* pixels;   // Pointer to the dynamically-allocated array of pixel data
    char outputFilename[256]; // Output filename for the image
};

/* Free a struct Image */
void free_image(struct Image *img)
{
    // First, check if the img pointer is not NULL
    if (img != NULL) {
        // Free the dynamically allocated array of pixels
        free(img->pixels);

        // After freeing the pixels, you might want to set the pointer to NULL
        // to avoid dangling pointers. This is optional and depends on how you manage memory.
        img->pixels = NULL;

        // Note: You do not need to free the img itself if it's not dynamically allocated.
        // If img was dynamically allocated (using malloc, calloc, or similar), you would
        // free it here as well. But based on the provided context, it's likely not needed.
    }
}

/* Opens and reads an image file, returning a pointer to a new struct Image.
 * On error, prints an error message and returns NULL. */
struct Image *load_image(const char *filename) {
    /* Open the file for reading in binary mode */
    FILE *f = fopen(filename, "rb"); // Use "rb" for reading binary files
    if (f == NULL) {
        fprintf(stderr, "File %s could not be opened.\n", filename);
        return NULL;
    }

    /* Attempt to read the image header */
    char format[5]; // Buffer to store the format, assuming "HS16 " including a space for separation
    int width, height;
    if (fscanf(f, "%4s %d %d", format, &width, &height) < 3 || strcmp(format, "HS16") != 0) {
        fprintf(stderr, "Invalid or corrupt image file: %s\n", filename);
        fclose(f); // Make sure to close the file before returning
        return NULL;
    }

    /* Skip any remaining header info (e.g., newline character) to start reading binary data */
    fseek(f, 1, SEEK_CUR);
    /* Allocate memory for the Image object */
    struct Image *img = malloc(sizeof(struct Image));
    if (img == NULL) {
        fprintf(stderr, "Memory allocation failed for image structure.\n");
        fclose(f);
        return NULL;
    }
    /* Set image dimensions */
    img->width = width;
    img->height = height;
    /* Allocate memory for pixel data */
    img->pixels = malloc(width * height * sizeof(struct Pixel));
    if (img->pixels == NULL) {
        fprintf(stderr, "Memory allocation failed for pixel data.\n");
        free(img); // Free the Image struct before returning
        fclose(f);
        return NULL;
    }
    /* Read pixel data */
    size_t itemsRead = fread(img->pixels, sizeof(struct Pixel), width * height, f);
    if (itemsRead < width * height) {
        fprintf(stderr, "Failed to read all pixel data from %s.\n", filename);
        free(img->pixels);
        free(img);
        fclose(f);
        return NULL;
    }

    /* Close the file */
    fclose(f);

    return img;
}

/* Write img to file filename. Return true on success, false on error. */
bool save_image(const struct Image *img, const char *filename) {
    /* Open the file for writing in binary mode */
    FILE *f = fopen(filename, "wb"); // "wb" is for writing binary files
    if (f == NULL) {
        fprintf(stderr, "Failed to open file %s for writing.\n", filename);
        return false;
    }

    /* Write the image header */
    if (fprintf(f, "HS16\n%d %d\n", img->width, img->height) < 0) {
        fprintf(stderr, "Failed to write header to file %s.\n", filename);
        fclose(f); // Make sure to close the file before returning
        return false;
    }

    /* Write the pixel data */
    size_t itemsWritten = fwrite(img->pixels, sizeof(struct Pixel), img->width * img->height, f);
    if (itemsWritten < img->width * img->height) {
        fprintf(stderr, "Failed to write all pixel data to %s.\n", filename);
        fclose(f); // Make sure to close the file before returning
        return false;
    }

    /* Close the file */
    fclose(f);

    return true;
}

/* Allocate a new struct Image and copy an existing struct Image's contents
 * into it. On error, returns NULL. */
struct Image *copy_image(const struct Image *source) {
    if (source == NULL) {
        return NULL; // Ensure the source image is not NULL
    }

    // Allocate memory for the new Image structure
    struct Image *copy = malloc(sizeof(struct Image));
    if (copy == NULL) {
        fprintf(stderr, "Memory allocation failed for the image copy.\n");
        return NULL;
    }

    // Copy the header information
    copy->width = source->width;
    copy->height = source->height;

    // Calculate the total number of pixels
    size_t totalPixels = source->width * source->height;

    // Allocate memory for the pixel data in the new image
    copy->pixels = malloc(totalPixels * sizeof(struct Pixel));
    if (copy->pixels == NULL) {
        fprintf(stderr, "Memory allocation failed for the pixel data.\n");
        free(copy); // Free the previously allocated Image structure
        return NULL;
    }

    // Copy the pixel data from the source image
    memcpy(copy->pixels, source->pixels, totalPixels * sizeof(struct Pixel));

    return copy;
}

/* Perform your first task.
 * (TODO: Write a better comment here, and rename the function.
 * You may need to add or change arguments depending on the task.)
 * Returns a new struct Image containing the result, or NULL on error. */
#include <limits.h> // For INT_MAX and INT_MIN
#define CLAMP(value, min, max) ((value) < (min) ? (min) : (value) > (max) ? (max) : (value))

struct Image *apply_NOISE(const struct Image *source, int noise_strength) {
    if (source == NULL) {
        fprintf(stderr, "Invalid input: source image is NULL.\n");
        return NULL;
    }

    // Validate noise strength input
    if (noise_strength < 0 || noise_strength > 100) {
        fprintf(stderr, "Invalid noise strength. Must be between 0 and 100.\n");
        return NULL;
    }

    // Scale the noise strength to the full 16-bit range
    double scale = noise_strength / 100.0 * 65535.0;

    struct Image *modified_image = (struct Image *)malloc(sizeof(struct Image));
    if (modified_image == NULL) {
        fprintf(stderr, "Memory allocation failed for modified image.\n");
        return NULL;
    }

    *modified_image = *source; // Copy header information (width, height)
    modified_image->pixels = (struct Pixel *)malloc(source->width * source->height * sizeof(struct Pixel));
    if (modified_image->pixels == NULL) {
        free(modified_image);
        fprintf(stderr, "Memory allocation failed for pixels.\n");
        return NULL;
    }

    // Apply scaled noise to each pixel
    for (int y = 0; y < source->height; ++y) {
        for (int x = 0; x < source->width; ++x) {
            const struct Pixel *source_pixel = &source->pixels[y * source->width + x];
            struct Pixel *modified_pixel = &modified_image->pixels[y * source->width + x];

            // Generate noise in the range of -scale to +scale
            double noise = ((rand() % 65536) / 65535.0 * 2.0 - 1.0) * scale;

            modified_pixel->red = CLAMP((int)source_pixel->red + (int)noise, 0, 65535);
            modified_pixel->green = CLAMP((int)source_pixel->green + (int)noise, 0, 65535);
            modified_pixel->blue = CLAMP((int)source_pixel->blue + (int)noise, 0, 65535);
        }
    }

    return modified_image;
}

/* Perform your second task.
 * (TODO: Write a better comment here, and rename the function.
 * You may need to add or change arguments depending on the task.)
 * Returns true on success, or false on error. */
bool apply_CODE(const struct Image *source) {
    if (source == NULL || source->pixels == NULL) {
        printf("Invalid image data.\n");
        return false;
    }

    printf("const int image_width = %d;\n", source->width);
    printf("const int image_height = %d;\n", source->height);
    printf("const struct Pixel image_data[] = {\n");

    int lineLength = 4; // Initial indent spaces
    for (int i = 0; i < source->width * source->height; ++i) {
        // Convert 16-bit values to 8-bit in-line
        uint8_t red = (uint8_t)((source->pixels[i].red * 255) / 65535);
        uint8_t green = (uint8_t)((source->pixels[i].green * 255) / 65535);
        uint8_t blue = (uint8_t)((source->pixels[i].blue * 255) / 65535);

        char pixelString[24]; // Buffer to hold one pixel data string
        int printed = snprintf(pixelString, sizeof(pixelString), "    {%u, %u, %u}", red, green, blue);

        if (i < source->width * source->height - 1) { // Not the last pixel, add comma and space
            snprintf(pixelString + printed, sizeof(pixelString) - printed, ", ");
            printed += 2;
        }

        if (lineLength + printed > 70) { // Check if adding this pixel would exceed line length
            printf("\n"); // New line
            lineLength = 4; // Reset line length and consider indent
        }

        printf("%s", pixelString);
        lineLength += printed;
    }

    printf("\n};\n"); // Close the image_data array

    return true;
}

int main(int argc, char *argv[]) {
    // Each image requires 3 arguments: input file, output file, and noise strength
    if (argc < 4 || (argc - 1) % 3 != 0) {
        fprintf(stderr, "Usage: %s INPUTFILE OUTPUTFILE NOISE_STRENGTH [INPUTFILE OUTPUTFILE NOISE_STRENGTH]...\n", argv[0]);
        return 1;
    }

    int numberOfImages = (argc - 1) / 3; // Calculate how many images are to be processed

    // Dynamically allocate an array of struct Image pointers
    struct Image **images = malloc(numberOfImages * sizeof(struct Image *));
    if (images == NULL) {
        fprintf(stderr, "Memory allocation failed for images array.\n");
        return 1;
    }

    for (int i = 0; i < numberOfImages; i++) {
        int argIndex = 1 + i * 3; // Calculate the starting index of arguments for the current image

        // Load the input image
        struct Image *in_img = load_image(argv[argIndex]);
        if (in_img == NULL) {
            continue; // Skip to the next image if loading fails
        }

        // Set the output filename for the input image
        strcpy(in_img->outputFilename, argv[argIndex + 1]);

        // Get the noise strength for the current image
        int noise_strength = atoi(argv[argIndex + 2]);

        // Apply the first process
        struct Image *out_img = apply_NOISE(in_img, noise_strength);
        if (out_img == NULL) {
            fprintf(stderr, "First process failed for image %d.\n", i + 1);
            free_image(in_img);
            continue; // Skip to the next image if processing fails
        }

        // Apply the second process
        apply_CODE(out_img);

        // Save the output image
        if (!save_image(out_img, in_img->outputFilename)) {
            fprintf(stderr, "Saving image to %s failed.\n", in_img->outputFilename);
        }

        // Free the memory for both input and output images
        free_image(in_img);
        free_image(out_img);

        // Assign the output image to the array of images
        images[i] = out_img;
    }

    // Free the dynamically allocated array of struct Image pointers
    free(images);

    return 0;
}